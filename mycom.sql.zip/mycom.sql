-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2018 at 03:24 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mycom`
--

-- --------------------------------------------------------

--
-- Table structure for table `child_category`
--

CREATE TABLE `child_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `child_category`
--

INSERT INTO `child_category` (`id`, `name`, `parent_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'vagetables', 1, 1, NULL, NULL),
(2, 'fruits', 1, 1, NULL, NULL),
(3, 'Soft drinks', 9, 1, NULL, NULL),
(4, 'Juice', 9, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_08_06_055445_create_tbl_product_table', 2),
(4, '2018_08_06_145642_create_tbl_category_table', 3),
(5, '2018_08_06_161126_create_tbl_category_table', 4),
(6, '2018_08_08_052309_create_child_category_table', 5),
(7, '2018_08_08_202557_create_tbl_slider_table', 6),
(8, '2018_08_09_194127_create_tbl_brands_table', 7),
(9, '2018_08_11_134552_create_tbl_customer_table', 8),
(10, '2018_08_11_173400_create_tbl_shipping_table', 9),
(11, '2018_08_11_185609_create_tbl_payment_table', 10),
(12, '2018_08_11_185708_create-tbl_order_table', 10),
(13, '2018_08_11_193007_create_tbl_product_details_table', 11),
(14, '2018_08_30_064321_create_tbl_contact_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brands`
--

CREATE TABLE `tbl_brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `brand_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_brands`
--

INSERT INTO `tbl_brands` (`id`, `brand_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'All brands', 1, NULL, NULL),
(2, 'Vegitables', 1, NULL, NULL),
(3, 'Fruits', 1, NULL, NULL),
(4, 'Juice', 1, NULL, NULL),
(5, 'pet food', 1, NULL, NULL),
(6, 'Bread and Brekary', 1, NULL, NULL),
(7, 'Clining', 1, NULL, NULL),
(8, 'Spices', 1, NULL, NULL),
(9, 'Dry fruits', 1, NULL, NULL),
(10, 'Dairy Products', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `parent_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Veggies &  Fruits', 0, 1, NULL, NULL),
(2, 'Branded Foods', 0, 1, NULL, NULL),
(3, 'Hoseholds', 0, 1, NULL, NULL),
(4, 'Kitchen', 0, 1, NULL, NULL),
(5, 'Short Code', 0, 1, NULL, NULL),
(6, 'Pet food', 0, 1, NULL, NULL),
(7, 'frozen foods', 0, 1, NULL, NULL),
(8, 'Bread and bekery', 0, 1, NULL, NULL),
(9, 'Beverages', 0, 1, NULL, NULL),
(10, 'vegetables', 1, 1, NULL, NULL),
(11, 'fruits', 1, 1, NULL, NULL),
(12, 'soft drinks', 9, 1, NULL, NULL),
(13, 'Juice', 9, 1, NULL, NULL),
(15, 'frozen snacks', 7, 1, NULL, NULL),
(16, 'frozen nonveg', 7, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `contact_id` int(10) UNSIGNED NOT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twiteer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `google` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dribble` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`contact_id`, `facebook`, `twiteer`, `google`, `instagram`, `dribble`, `created_at`, `updated_at`) VALUES
(1, 'https://www.facebook.com/', 'https://www.twitter.com', 'https://www.google.com', 'https://www.instagram.com', 'https://www.dribbble.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `user_name`, `password`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'arnab', '$2y$10$z30AprOwtdAiwrNMtmFUT.ZczYyqQEXn2mDgdAE4uRkriwxHkJOeq', 'arnab@gmail.com', '01830850620', NULL, NULL),
(2, 'ramjan', '$2y$10$.K9shvV7eR2KlVe6ESLX/utxIoICbqOiCv5LkKnr7vt9k/TGI4quS', 'ramjan@gmail.com', '234234234', NULL, NULL),
(3, 'ramjan', '$2y$10$CjTxM4zTWvkddNcOlZOq5u4H0uWMRu7WD.CtfKjKmVYN89j1UPGYG', 'ramjan@gmail.com', '234234234', NULL, NULL),
(4, 'ramjan', '$2y$10$ZBRFbD0ZfYRYYgnnoOdWbOg5.K6E6bxldPAMkHujHetTkJHVerqJC', 'ramjan@gmail.com', '234234234', NULL, NULL),
(5, 'failsal', '$2y$10$2TkHTQKKNC5I3oT.2U6IqeTPagDBoKD.LfZCy2LEPXTBzklT6xfWK', 'faisal@gmail.com', '01830850630', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `order_count` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `payment_id`, `customer_id`, `shipping_id`, `order_count`, `order_total`, `order_status`, `created_at`, `updated_at`) VALUES
(1, 6, 4, 4, '5', '3,944.60', 'pending', NULL, NULL),
(2, 7, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(3, 8, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(4, 9, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(5, 10, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(6, 11, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(7, 12, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(8, 13, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(9, 14, 1, 5, '2', '1,089.00', 'pending', NULL, NULL),
(10, 15, 1, 6, '4', '1,742.40', 'pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_quantity`, `created_at`, `updated_at`) VALUES
(1, 1, 6, 'Basmati Rise', '2200', '1', NULL, NULL),
(2, 1, 7, 'Pepsi Soft Drink', '80', '2', NULL, NULL),
(3, 1, 5, 'oil', '450', '2', NULL, NULL),
(4, 2, 5, 'oil', '450', '2', NULL, NULL),
(5, 3, 5, 'oil', '450', '2', NULL, NULL),
(6, 4, 5, 'oil', '450', '2', NULL, NULL),
(7, 5, 5, 'oil', '450', '2', NULL, NULL),
(8, 6, 5, 'oil', '450', '2', NULL, NULL),
(9, 7, 5, 'oil', '450', '2', NULL, NULL),
(10, 8, 5, 'oil', '450', '2', NULL, NULL),
(11, 9, 5, 'oil', '450', '2', NULL, NULL),
(12, 10, 28, 'Pepper Salami', '80', '3', NULL, NULL),
(13, 10, 26, 'dog food', '1200', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(10) UNSIGNED NOT NULL,
  `payment_getway` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`payment_id`, `payment_getway`, `payment_status`, `created_at`, `updated_at`) VALUES
(1, 'on', 'pending', NULL, NULL),
(2, 'on', 'pending', NULL, NULL),
(3, 'on', 'pending', NULL, NULL),
(4, 'on', 'pending', NULL, NULL),
(5, 'on', 'pending', NULL, NULL),
(6, 'on', 'pending', NULL, NULL),
(7, 'hand_delivery', 'pending', NULL, NULL),
(8, 'hand_delivery', 'pending', NULL, NULL),
(9, 'hand_delivery', 'pending', NULL, NULL),
(10, 'hand_delivery', 'pending', NULL, NULL),
(11, 'hand_delivery', 'pending', NULL, NULL),
(12, 'hand_delivery', 'pending', NULL, NULL),
(13, 'hand_delivery', 'pending', NULL, NULL),
(14, 'hand_delivery', 'pending', NULL, NULL),
(15, 'hand_delivery', 'pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_id` tinyint(4) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tags` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `title`, `cat_id`, `image`, `short_description`, `long_description`, `price`, `size`, `color`, `tags`, `status`, `created_at`, `updated_at`) VALUES
(2, 'tometo coch', 1, 'admin/upload/4a74f4.jpg', 'short descrioption', 'long descriotion', '220', 'all', 'fresh', '', 1, NULL, NULL),
(3, 'packet product', 2, 'admin/upload/f6f1b5.jpg', 'short description', 'long description', '1000', 'small, medium , large', 'all', '', 1, NULL, NULL),
(4, 'juice', 9, 'admin/upload/9aab76.jpg', 'short decriptions', 'long descriptio', '250', 'none', 'yellow', 'beverages', 1, NULL, NULL),
(5, 'oil', 4, 'admin/upload/65ffd1.png', 'short desctioino&nbsp;', 'long descriptin&nbsp;', '450', 'samill, big', 'white , mix', 'hot offers', 1, NULL, NULL),
(6, 'Basmati Rise', 4, 'admin/upload/c13223.png', 'short description..........', 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', '2200', 'samill, big', 'white', 'hot offers', 1, NULL, NULL),
(7, 'Pepsi Soft Drink', 9, 'admin/upload/aa6d22.png', 'shor&nbsp; descti[ption', 'long description', '80', 'samill, big', 'black', 'hot offers', 1, NULL, NULL),
(8, 'Dogs Food', 6, 'admin/upload/e72074.png', 'short description', 'long decription', '500', 'samill, big', 'white', 'hot offers', 1, NULL, NULL),
(10, 'mosla', 4, 'admin/upload/34a5e5.png', 'short description', 'long description', '1000', 'bandel', 'original', 'special offer', 1, NULL, NULL),
(11, 'store', 1, 'admin/upload/baf609.jpg', 'short description', 'long description', 'none', 'none', 'none', 'special offer', 1, NULL, NULL),
(12, 'Fresh Cauliflowe', 10, 'admin/upload/486f530.png', 'short descrioption', 'long description', '100', 'samill, big', 'white', 'vegetable', 1, NULL, NULL),
(13, 'Fresh Bananas', 11, 'admin/upload/198e429.png', 'short description&nbsp;', 'long descrioption', '60', 'samill, big', 'yellow', 'fruits', 1, NULL, NULL),
(14, 'Fresh Brinjal Bharta', 10, 'admin/upload/76c0431.png', 'short descrioption', 'long description', '120', 'samill, big', 'brougn', 'vegetable', 1, NULL, NULL),
(15, 'Fresh Spinach', 10, 'admin/upload/bf2729.png', 'short desctiption', 'long description', '40', 'samill, big', 'fresh', 'vegetable', 1, NULL, NULL),
(16, 'Fresh Basket Onion', 10, 'admin/upload/c10ef33.png', 'short description', 'long description', '200', 'samill, medium', 'origianl', 'vegetable', 1, NULL, NULL),
(17, 'Fresh Sweet Lime', 11, 'admin/upload/bd99d32.png', 'Short description', 'long description', '220', 'samill, medium', 'origianl', 'fruits', 1, NULL, NULL),
(18, 'Fresh Apple Red', 11, 'admin/upload/aaad611.png', 'short description', 'long description', '220', 'samill, medium', 'origianl', 'fruits', 1, NULL, NULL),
(19, 'Fresh Strawberry', 11, 'admin/upload/bb2c336.png', 'short description', 'long descripion', '320', 'small', 'origianl', 'fruits', 1, NULL, NULL),
(20, 'Dishwash Gel, Lemon', 3, 'admin/upload/068f317.png', 'sort decription', 'long description', '150', 'samill, big', 'yellow, green', 'households', 1, NULL, NULL),
(21, 'Dish Wash Bar', 3, 'admin/upload/5c15220.png', 'short description', 'long description', '450', 'samill, big', 'yellow, green, and red', 'households', 1, NULL, NULL),
(22, 'Air Freshener', 3, 'admin/upload/6228e19.png', 'short decription', 'long description', '270', 'samill', 'yellow, green, and red', 'households', 1, NULL, NULL),
(23, 'Toilet Cleaner Expert', 3, 'admin/upload/9a7f020.png', 'short descritoion', 'long decrtiption', '140', 'samill', 'yellow, green', 'households', 1, NULL, NULL),
(24, 'vegetables', 4, 'admin/upload/6a71b4.png', 'short description', 'long description', '450', 'all', 'original', 'kitchen', 1, NULL, NULL),
(25, 'feed', 6, 'admin/upload/eb88b7.png', 'short code', 'short code', '450', 'samill', 'white', 'pet food', 1, NULL, NULL),
(26, 'dog food', 6, 'admin/upload/1ee7a22.png', 'short description', 'long description', '1200', 'samill, big', 'origianl', 'pet food', 1, NULL, NULL),
(27, 'per food 3', 6, 'admin/upload/0c42b6.png', 'short description', 'long description', '1000', 'samill, big', 'white', 'pet food', 1, NULL, NULL),
(28, 'Pepper Salami', 15, 'admin/upload/35be95.png', 'short description', 'long descrioption', '80', 'samll', 'yellow, green', 'froze snacks', 1, NULL, NULL),
(29, 'Kesar Mango Pulp', 15, 'admin/upload/23c2c68.png', 'short description&nbsp;', 'long description', '80', 'small', 'origianl', 'froze snacks', 1, NULL, NULL),
(30, 'Frozen Sweet Corn', 15, 'admin/upload/d8add60.png', 'short desciption', 'long descripotion', '120', 'samill, medium', 'white', 'froze snacks', 1, NULL, NULL),
(31, 'Chicken Nuggets', 15, 'admin/upload/2ccd271.png', 'short description is here', 'long description is here', '120', 'samill', 'yellow, green', 'froze snacks', 1, NULL, NULL),
(32, 'Orange Soft Drink', 12, 'admin/upload/a711a49.png', 'short description', 'long description', '320', 'samill', 'yellow, green', 'soft drinks', 1, NULL, NULL),
(33, 'Prune Juice - Sunsweet', 12, 'admin/upload/951d552.png', 'sort descirpiton', 'long description&nbsp;', '120', 'samill', 'black', 'soft drinks', 1, NULL, NULL),
(34, 'Coco Cola Zero Can', 12, 'admin/upload/1966915.png', 'short description', 'long description', '45', 'samill', 'black', 'soft drinks', 1, NULL, NULL),
(35, 'Can Bottle', 12, 'admin/upload/e760b23.jpg', 'short description', 'long descriotion', '45', 'samill, medium', 'yellow, green', 'bangaldesh', 1, NULL, NULL),
(36, 'Utensils', 2, 'admin/upload/365b013.jpg', 'shrot description&nbsp;', 'long description', '1000', 'all', 'steel', 'utensils', 1, NULL, NULL),
(37, 'Hair Care', 2, 'admin/upload/9e28514.jpg', 'short description long description', 'long description', '1000', 'all', 'origianl', 'hair', 1, NULL, NULL),
(38, 'Cookies', 2, 'admin/upload/c5dde15.jpg', 'short descriotion', 'long description', '1200', 'all', 'origianl', 'cookies', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shipping`
--

CREATE TABLE `tbl_shipping` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_shipping`
--

INSERT INTO `tbl_shipping` (`id`, `name`, `phone`, `address`, `type`, `created_at`, `updated_at`) VALUES
(1, 'faisal Ahemd', '01830850620', 'Cumilla', 'home', NULL, NULL),
(2, 'fsfdksdfsdf', '01830850630', 'Cumilla', 'office', NULL, NULL),
(3, 'arnab', '424324234', 'Cumilla', 'office', NULL, NULL),
(4, 'arnab', '424324234', 'Cumilla', 'office', NULL, NULL),
(5, 'fahm', '01e830850630', 'Cumilla', 'commercial', NULL, NULL),
(6, 'arnab', '01830850620', 'Cumilla', 'commercial', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(10) UNSIGNED NOT NULL,
  `slider_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `slider_name`, `slider_image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'first silder', 'admin/upload/7bc231.jpg', 1, NULL, NULL),
(2, 'second slider', 'admin/upload/6c5872.jpg', 1, NULL, NULL),
(3, 'third sliddr', 'admin/upload/5d7233.jpg', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `address`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Ramjan Hosen Arnab', 'rharnab@gmail.com', '$2y$10$fjEtlaSqBT2eioahwTg5FORsoFLl2G2KzLP5uqvBYKyNd/XGKmoga', '01830850620', 'Cumilla, Dhaka, Bagladesh', 'TGTDUTjsmHb11o6C6EgS4PqvwV5VFG86bbeMTfvzcAnDw7kufEWsalGXvSRs', '2018-08-05 22:33:37', '2018-08-05 22:33:37'),
(2, 'fahim', 'fahim@gmail.com', '$2y$10$JhZ2tJ2fWAWdS0TQjN12JuC9LSTA0oeSetCYMlM4QcezeeKURfFTu', '01620601859', 'dhaka, bangladesh', NULL, '2018-09-01 22:39:33', '2018-09-01 22:39:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `child_category`
--
ALTER TABLE `child_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tbl_brands`
--
ALTER TABLE `tbl_brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `child_category`
--
ALTER TABLE `child_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_brands`
--
ALTER TABLE `tbl_brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `contact_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_shipping`
--
ALTER TABLE `tbl_shipping`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
